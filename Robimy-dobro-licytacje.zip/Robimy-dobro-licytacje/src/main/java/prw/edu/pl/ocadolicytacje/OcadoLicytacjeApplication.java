package prw.edu.pl.ocadolicytacje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class OcadoLicytacjeApplication {

    public static void main(String[] args) {
        SpringApplication.run(OcadoLicytacjeApplication.class, args);
    }

}
